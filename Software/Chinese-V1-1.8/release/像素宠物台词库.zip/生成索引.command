#!/bin/zsh
PET_QUOTE_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "$PET_QUOTE_DIR/生成台词库.py"
read "?按回车关闭…"
