"""Each UTF-8 TSV row is ID<TAB>quote. Build a seekable little-endian SD index.
Re-run after editing dog.tsv/person.tsv; existing words are never regenerated.
"""
from pathlib import Path
import itertools,struct
ROOT=Path(__file__).resolve().parent/'台词库'
DOG_A='汪，早上好|今天精神不错|尾巴已经准备好了|鼻子发现了新线索|小狗巡逻中|这里有一只快乐小狗|刚才跑得真快|让我伸个懒腰|今天也想交朋友|耳朵竖起来啦|我要出发啦|让我闻闻这里|这块地方归我巡逻|四只爪子闲不住|风里好像有故事|路边有新的脚印|我又回来啦|今天也很喜欢你|小狗正在认真思考|趴一会儿也不错|先摇三下尾巴|我听见快乐的声音|心情像晴天一样|我带着好心情来啦'.split('|')
DOG_B='陪我出去走走吧|一起去追风吧|可以摸摸我的头吗|给我一点鼓励吧|别忘了起来活动|我们去找小伙伴吧|跑完这圈就休息|今天也要开心呀|你忙，我在旁边陪着|这次换你跟着我|我会乖乖等你回来|要不要比比谁快|去看看远处的风景|快乐值得多跑两圈|慢慢走也很好呀|把烦恼留在身后吧|这条路我来带队|让我再巡视一圈|休息够了就出发|我负责认真卖萌|有空记得陪我玩|别急，我陪着你|今天想发现新地方|接下来往哪边走呢'.split('|')
PERSON_A='今天是新的一天|先站起来活动一下|一步一步往前走|让我看看这边|走到这里刚刚好|小人散步中|刚才想到一个点子|今天也在努力生活|停一下看看风景|保持一点好奇心|伸展一下肩膀|换个方向试试看|我又溜达回来啦|慢一点也没关系|小小的进步也算数|脑袋正在加载灵感|脚步轻快一点|偶尔发呆也很好|今天又多走了几步|这里是我的小天地|带着好心情出发|先深呼吸一下|走累了歇一歇|生活需要一点留白'.split('|')
PERSON_B='要一起散步吗|记得喝一口水|今天也要加油呀|不用着急，慢慢来|下一站去哪里呢|忙完记得放松|眼睛也要休息一下|给自己一点掌声吧|还有好多风景可看|先把肩膀放松下来|好想法值得记下来|我们继续往前走|休息好再继续吧|让心情轻松一点|有空看看窗外吧|别忘了照顾自己|偶尔换条路走走|也许灵感就在前面|今天做点喜欢的事|小步子也能到远方|认真玩耍也很重要|让我在这里陪着你|现在就当散步时间|把笑容带在身上吧'.split('|')
def build(path):
    raw=path.read_bytes(); rows=raw.splitlines(keepends=True); offsets=[];pos=0;seen=set()
    if not rows:raise ValueError('台词库不能为空')
    for i,row in enumerate(rows,1):
        text=row.decode('utf-8').rstrip('\r\n'); key,quote=text.split('\t',1)
        if int(key)!=i or not quote.strip() or len(quote.encode())>120 or any(ord(c)<32 for c in quote):raise ValueError(f'{path.name}第{i}句无效，需连续编号且台词不超过120字节')
        if quote in seen:raise ValueError(f'{path.name}第{i}句重复')
        seen.add(quote); offsets.append(pos);pos+=len(row)
    offsets.append(pos)
    if pos>=2**32:raise ValueError('单个词库需小于4GB，请拆分')
    payload=struct.pack('<3I',0x31515048,len(rows),pos)+struct.pack(f'<{len(offsets)}I',*offsets)
    path.with_suffix('.idx').write_bytes(payload)
    # Verify every ID and byte span, not only the count.
    for i in range(len(rows)):
        assert raw[offsets[i]:offsets[i+1]].decode().split('\t',1)[0]==str(i+1)
    print(f'{path.name}: {len(rows)}句，编号1～{len(rows)}，文本{pos}字节，索引{len(payload)}字节')
if __name__=='__main__':
    ROOT.mkdir(exist_ok=True)
    for name,a,b in [('dog',DOG_A,DOG_B),('person',PERSON_A,PERSON_B)]:
        p=ROOT/(name+'.tsv')
        if not p.exists():p.write_text(''.join(f'{i}\t{x}，{y}。\n' for i,(x,y) in enumerate(itertools.product(a,b),1)),encoding='utf-8')
        build(p)
