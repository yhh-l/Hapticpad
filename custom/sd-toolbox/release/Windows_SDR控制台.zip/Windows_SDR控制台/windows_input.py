"""Windows input loop. All callbacks return immediately; CAT runs elsewhere."""
import ctypes
from ctypes import wintypes
import os
import threading

ACTIONS = ('step_down', 'step_up', 'mode_prev', 'mode_next', 'band_prev', 'band_next')

class WindowsInput:
    def __init__(self, submit, is_armed, error):
        self.submit, self.is_armed, self.error = submit, is_armed, error
        self.thread_id = None
        self.ready = threading.Event()
        if os.name != 'nt': raise RuntimeError('全局旋钮 / 六键接管仅支持 Windows；本机可用模拟按钮测试')
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        if not self.ready.wait(3): raise RuntimeError('Windows 输入服务未就绪')
        if self.thread_id is None: raise RuntimeError('Windows 输入服务启动失败')
    def enable(self, value):
        if self.thread_id:
            ctypes.windll.user32.PostThreadMessageW(self.thread_id, 0x8001, int(value), 0)
    def close(self):
        if self.thread_id: ctypes.windll.user32.PostThreadMessageW(self.thread_id, 0x0012, 0, 0)
    def _run(self):
        user, kernel = ctypes.windll.user32, ctypes.windll.kernel32
        LRESULT = ctypes.c_ssize_t
        HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
        class Point(ctypes.Structure):
            _fields_ = [('x', wintypes.LONG), ('y', wintypes.LONG)]
        class Mouse(ctypes.Structure):
            _fields_ = [('pt', Point), ('mouseData', wintypes.DWORD), ('flags', wintypes.DWORD),
                        ('time', wintypes.DWORD), ('dwExtraInfo', ctypes.c_size_t)]
        user.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
        user.SetWindowsHookExW.restype = wintypes.HANDLE
        user.CallNextHookEx.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
        user.CallNextHookEx.restype = LRESULT
        user.UnhookWindowsHookEx.argtypes = [wintypes.HANDLE]
        kernel.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        kernel.GetModuleHandleW.restype = wintypes.HMODULE
        user.GetAsyncKeyState.argtypes = [ctypes.c_int]
        user.GetAsyncKeyState.restype = ctypes.c_short
        user.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
        user.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
        registered = []
        enabled = False
        remainder = 0
        def unregister():
            for n in registered: user.UnregisterHotKey(None, n)
            registered.clear()
        @HOOKPROC
        def mouse_hook(code, message, data):
            nonlocal remainder
            if code>=0 and message==0x020A and enabled and self.is_armed() and user.GetAsyncKeyState(0x12)&0x8000:
                event = ctypes.cast(data, ctypes.POINTER(Mouse)).contents
                delta = ctypes.c_short((event.mouseData >> 16)&0xffff).value
                remainder += delta
                ticks = int(remainder/120)
                remainder -= ticks*120
                if ticks: self.submit('tune', ticks)
                return 1
            return user.CallNextHookEx(None, code, message, data)
        hook = user.SetWindowsHookExW(14, mouse_hook, kernel.GetModuleHandleW(None), 0)
        if not hook:
            self.error('无法安装 Windows 鼠标监听'); self.ready.set(); return
        # Ensure message queue exists before exposing the thread id.
        msg = wintypes.MSG()
        user.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)
        self.thread_id = kernel.GetCurrentThreadId()
        self.ready.set()
        try:
            while True:
                result = user.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if result<=0: break
                if msg.message==0x8001:
                    unregister(); enabled = False; remainder = 0
                    if msg.wParam and self.is_armed():
                        for n in range(6):
                            if not user.RegisterHotKey(None, n+1, 0x4003, 0x70+n):
                                unregister(); self.error('Ctrl+Alt+F1～F6 有快捷键冲突，已停止接管'); break
                            registered.append(n+1)
                        enabled = len(registered)==6
                elif msg.message==0x0312 and enabled and self.is_armed():
                    index = int(msg.wParam)-1
                    if 0<=index<6: self.submit(ACTIONS[index])
        finally:
            unregister(); user.UnhookWindowsHookEx(hook); self.thread_id = None
