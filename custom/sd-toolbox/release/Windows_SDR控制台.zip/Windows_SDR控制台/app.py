"""Hapticpad universal SDR console. Run with Python 3.10+ (Tk enabled)."""
import os
from pathlib import Path
import queue
import tkinter as tk
from tkinter import ttk
import webbrowser
from radio import Controller, Demo, Hamlib, OmniRig, STEPS
from windows_input import WindowsInput, ACTIONS

LABELS = ('步进减小', '步进增大', '上一模式', '下一模式', '上一频段', '下一频段')
class App:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.controller = Controller(lambda k,v:self.events.put((k,v)))
        self.input = None
        self.connected = False
        root.title('Hapticpad · Windows SDR 通用控制台 1.0')
        root.geometry('820x760'); root.minsize(760, 700)
        style = ttk.Style(); style.theme_use('clam')
        style.configure('TFrame', background='#f4f6f9')
        style.configure('TLabel', background='#f4f6f9', font=('Microsoft YaHei UI',11))
        style.configure('TButton', font=('Microsoft YaHei UI',11), padding=8)
        panel = ttk.Frame(root, padding=24); panel.pack(fill='both', expand=True)
        ttk.Label(panel,text='SDR 通用控制台',font=('Microsoft YaHei UI',24,'bold')).pack(anchor='w')
        ttk.Label(panel,text='旋钮调频 · 六键切换步进 / 模式 / 频段').pack(anchor='w',pady=(4,18))
        row = ttk.Frame(panel); row.pack(fill='x')
        self.backend = tk.StringVar(value='演示（不连接电台）')
        choices = ttk.Combobox(row,textvariable=self.backend,state='readonly',width=26,
                              values=('演示（不连接电台）','Hamlib · rigctld TCP','OmniRig · Rig 1','OmniRig · Rig 2'))
        choices.pack(side='left'); choices.bind('<<ComboboxSelected>>',lambda _:self.disconnect())
        self.connect_btn=ttk.Button(row,text='连接',command=self.connect); self.connect_btn.pack(side='left',padx=10)
        ttk.Button(row,text='断开',command=self.disconnect).pack(side='left')
        settings=ttk.Frame(panel); settings.pack(fill='x',pady=12)
        ttk.Label(settings,text='Hamlib 地址').pack(side='left')
        self.host=tk.StringVar(value='127.0.0.1'); ttk.Entry(settings,textvariable=self.host,width=22).pack(side='left',padx=8)
        ttk.Label(settings,text='端口').pack(side='left')
        self.port=tk.StringVar(value='4532'); ttk.Entry(settings,textvariable=self.port,width=7).pack(side='left',padx=8)
        self.frequency=tk.StringVar(value='— . ——— ——— MHz')
        ttk.Label(panel,textvariable=self.frequency,font=('Consolas',32,'bold'),foreground='#137b6a').pack(anchor='w',pady=(20,8))
        self.radio=tk.StringVar(value='模式 —     步进 100 Hz')
        ttk.Label(panel,textvariable=self.radio,font=('Microsoft YaHei UI',15)).pack(anchor='w')
        self.arm_btn=ttk.Button(panel,text='开始接管旋钮与六键',command=self.arm,state='disabled'); self.arm_btn.pack(fill='x',pady=18)
        self.invert=tk.BooleanVar(value=False)
        ttk.Checkbutton(panel,text='反转调频方向（顺时针降频时勾选）',variable=self.invert,
                        command=lambda:setattr(self.controller,'invert',self.invert.get())).pack(anchor='w')
        grid=ttk.Frame(panel);grid.pack(fill='x',pady=14)
        for n,(action,label) in enumerate(zip(ACTIONS,LABELS)):
            grid.columnconfigure(n%3,weight=1)
            ttk.Button(grid,text=f'{n+1}  {label}',command=lambda a=action:self.controller.submit(a)).grid(row=n//3,column=n%3,sticky='ew',padx=3,pady=3)
        demo=ttk.Frame(panel);demo.pack(fill='x')
        ttk.Button(demo,text='模拟旋钮 −1 格',command=lambda:self.controller.submit('tune',-1)).pack(side='left',expand=True,fill='x',padx=3)
        ttk.Button(demo,text='模拟旋钮 +1 格',command=lambda:self.controller.submit('tune',1)).pack(side='left',expand=True,fill='x',padx=3)
        self.status=tk.StringVar(value='未连接。先用演示验证操作，再选择真实 CAT 接口。')
        ttk.Label(panel,textvariable=self.status,wraplength=750,foreground='#1c5b8a').pack(anchor='w',pady=16)
        ttk.Label(panel,text='设备请切到「SDR通用」。接管期间 Alt+滚轮会调频，普通滚轮不受影响。\n任何鼠标的 Alt+滚轮都会被识别；按“停止接管”立即释放全局快捷键。\n显示频率来自 CAT 回读；本控制台没有发射 / PTT 操作。',wraplength=750).pack(anchor='w')
        ttk.Button(panel,text='打开中文接线与软件设置说明',command=lambda:webbrowser.open((Path(__file__).parent/'使用说明.html').as_uri())).pack(anchor='w',pady=12)
        root.protocol('WM_DELETE_WINDOW',self.close)
        if os.name=='nt':
            try:
                self.input=WindowsInput(self.controller.submit,lambda:self.controller.armed,
                                        lambda e:self.events.put(('hook_error',e)))
            except Exception as e: self.status.set(str(e))
        else: self.status.set('当前不是 Windows：可以使用演示和界面按钮，无法接管硬件全局输入。')
        self.current_mode='—'
        self.poll()
    def connect(self):
        choice=self.backend.get()
        try:
            if choice.startswith('Hamlib'):
                host,port=self.host.get().strip(),int(self.port.get())
                if not host or not 1<=port<=65535: raise ValueError('地址或端口无效')
                factory=lambda:Hamlib(host,port)
            elif choice.startswith('OmniRig'):
                rig=2 if choice.endswith('2') else 1
                factory=lambda:OmniRig(rig)
            else: factory=Demo
            self.disconnect();self.connect_btn.configure(state='disabled')
            self.status.set('正在连接；尚未接管输入…');self.controller.connect(factory)
        except Exception as e: self.status.set(str(e))
    def disconnect(self):
        self.controller.disconnect()
        if self.input: self.input.enable(False)
        self.frequency.set('— . ——— ——— MHz')
        self.status.set('已断开；输入已释放。')
    def arm(self):
        self.controller.arm(not self.controller.armed)
        if self.input: self.input.enable(self.controller.armed)
    def poll(self):
        while True:
            try: kind,value=self.events.get_nowait()
            except queue.Empty: break
            if kind=='radio':
                self.frequency.set(f"{value['frequency']/1000000:,.6f} MHz")
                self.current_mode=value['mode'];self.update_step(value['step'])
            elif kind=='step': self.update_step(value)
            elif kind=='state':
                if 'connected' in value: self.connected=value['connected'];self.connect_btn.configure(state='normal')
                armed=value.get('armed',self.controller.armed)
                self.arm_btn.configure(state='normal' if self.connected else 'disabled',text='停止接管（释放输入）' if armed else '开始接管旋钮与六键')
                if not armed and self.input:self.input.enable(False)
                if self.connected:self.status.set(('演示 · 不控制真实电台。' if self.backend.get().startswith('演示') else 'CAT 已连接。')+('正在接管输入。' if armed else '按“开始接管”后旋钮和六键才生效。'))
            elif kind in ('error','hook_error'):
                self.controller.arm(False)
                if self.input:self.input.enable(False)
                self.status.set('已停止：'+str(value)); self.connect_btn.configure(state='normal')
        self.root.after(80,self.poll)
    def update_step(self,step):self.radio.set(f'模式 {self.current_mode}     步进 {step:,} Hz')
    def close(self):
        self.controller.close()
        if self.input:self.input.close()
        self.root.destroy()

if __name__=='__main__':
    App(tk.Tk()).root.mainloop()
