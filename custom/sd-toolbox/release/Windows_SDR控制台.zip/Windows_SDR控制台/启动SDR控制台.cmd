@echo off
cd /d "%~dp0"
py -3 -c "import tkinter" >nul 2>nul
if errorlevel 1 (
  echo Python 3 with Tkinter is required. Install Python from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
py -3 app.py
if errorlevel 1 pause
