# Readable source passed to PowerShell -Command. No execution-policy changes.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$omni = $null
$modes = @{CW=0x800000; CWR=0x1000000; USB=0x2000000; LSB=0x4000000; PKTUSB=0x8000000; PKTLSB=0x10000000; AM=0x20000000; FM=0x40000000}
function FrequencyField($r) {
    $v = [int]$r.Vfo
    if (($v -eq 0x800 -or $v -eq 0x80 -or $v -eq 0x100) -and $r.IsParamReadable(4)) { return 'FreqA' }
    if (($v -eq 0x1000 -or $v -eq 0x200 -or $v -eq 0x400) -and $r.IsParamReadable(8)) { return 'FreqB' }
    if ($r.IsParamReadable(2)) { return 'Freq' }
    throw 'Receiving VFO frequency is not readable'
}
while ($null -ne ($line = [Console]::ReadLine())) {
    try {
        $q = ConvertFrom-Json $line
        if ($null -eq $omni) { $omni = New-Object -ComObject OmniRig.OmniRigX }
        if ([int]$q.rig -eq 1) { $rig = $omni.Rig1 }
        elseif ([int]$q.rig -eq 2) { $rig = $omni.Rig2 }
        else { throw 'Rig must be 1 or 2' }
        if ([int]$rig.Status -ne 4) { throw ('OmniRig offline: ' + $rig.StatusStr) }
        if ($q.action -eq 'read') {
            $mode = 'UNKNOWN'
            foreach ($k in $modes.Keys) { if ([int]$rig.Mode -eq $modes[$k]) { $mode = $k } }
            $field = FrequencyField $rig
            $result = @{ok=$true; frequency=[int]$rig.$field; mode=$mode}
        } elseif ($q.action -eq 'frequency') {
            # Change receiving VFO only; never force simplex or alter split/PTT.
            if ([int]$rig.Tx -eq 0x400000) { throw 'Radio is transmitting; wait for receive' }
            $field = FrequencyField $rig
            $bit = @{Freq=2; FreqA=4; FreqB=8}[$field]
            if (!$rig.IsParamWriteable($bit)) { throw 'Receiving VFO is not writable; check OmniRig driver' }
            $rig.$field = [int]$q.value
            $result = @{ok=$true}
        } elseif ($q.action -eq 'mode') {
            if (!$modes.ContainsKey([string]$q.value)) { throw 'Unsupported mode' }
            $bit = $modes[[string]$q.value]
            if (!$rig.IsParamWriteable($bit)) { throw 'Mode is not writable in this driver' }
            if ([int]$rig.Tx -eq 0x400000) { throw 'Radio is transmitting; wait for receive' }
            $rig.Mode = $bit
            $result = @{ok=$true}
        } else { throw 'Unknown action' }
        [Console]::WriteLine((ConvertTo-Json -Compress $result))
    } catch {
        [Console]::WriteLine((ConvertTo-Json -Compress @{ok=$false; error=$_.Exception.Message}))
    }
}
