"""Receive-side CAT control. Standard library only; no transmit commands."""
import json
import math
import os
from pathlib import Path
import queue
import socket
import subprocess
import threading
import time

MODES = ('LSB', 'USB', 'CW', 'CWR', 'AM', 'FM', 'PKTUSB', 'PKTLSB')
STEPS = (1, 10, 50, 100, 500, 1000, 5000, 10000, 100000)
BANDS = (('160米', 1900000), ('80米', 3700000), ('40米', 7100000),
         ('30米', 10120000), ('20米', 14200000), ('17米', 18100000),
         ('15米', 21200000), ('12米', 24940000), ('10米', 28400000),
         ('6米', 50100000), ('2米', 145000000), ('70厘米', 435000000))
MODE_BITS = {'CW':0x800000, 'CWR':0x1000000, 'USB':0x2000000, 'LSB':0x4000000,
             'PKTUSB':0x8000000, 'PKTLSB':0x10000000, 'AM':0x20000000, 'FM':0x40000000}

class CatError(RuntimeError):
    pass

def frequency(value):
    n = float(value)
    if not math.isfinite(n) or not n.is_integer() or not 100000 <= n <= 2000000000:
        raise CatError('频率需为 100 kHz～2 GHz 内的整数 Hz；还须符合电台本身范围')
    return int(n)

class Demo:
    def __init__(self): self.freq, self.mode = 7100000, 'LSB'
    def read(self): return {'frequency':self.freq, 'mode':self.mode}
    def set_frequency(self, value): self.freq = frequency(value)
    def set_mode(self, value): self.mode = value
    def close(self): pass

class Hamlib:
    """One serialized ERP connection; no commands are retried after an error."""
    def __init__(self, host='127.0.0.1', port=4532):
        self.sock = socket.create_connection((host, int(port)), timeout=2)
        self.sock.settimeout(2)
        self.stream = self.sock.makefile('rb')

    def command(self, command):
        self.sock.sendall(('+' + command + '\n').encode('ascii'))
        fields = {}
        for _ in range(64):
            raw = self.stream.readline(4097)
            if not raw: raise CatError('CAT 连接已断开')
            if len(raw)>4096 or not raw.endswith(b'\n'): raise CatError('CAT 响应过长或不完整')
            line = raw.decode('ascii', errors='strict').strip()
            if line.startswith('RPRT '):
                code = int(line[5:])
                if code: raise CatError(f'Hamlib 返回错误 {code}：电台可能不支持此操作')
                return fields
            if ': ' in line:
                k, v = line.split(': ', 1); fields[k] = v
        raise CatError('CAT 响应未结束')

    def read(self):
        f = self.command('f'); m = self.command('m')
        return {'frequency':frequency(f['Frequency']), 'mode':m['Mode']}
    def set_frequency(self, value): self.command(f'F {frequency(value)}')
    def set_mode(self, value):
        if value not in MODES: raise CatError('模式不支持')
        self.command(f'M {value} 0')  # Hamlib 0 = backend normal passband.
    def close(self):
        try: self.stream.close()
        finally: self.sock.close()

class OmniRig:
    def __init__(self, rig=1):
        if os.name != 'nt': raise CatError('OmniRig 仅支持 Windows')
        script = (Path(__file__).parent/'omnirig.ps1').read_text(encoding='utf-8')
        self.process = subprocess.Popen(
            ['powershell.exe', '-NoProfile', '-STA', '-Command', script],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW)
        self.responses = queue.Queue()
        def receive():
            for line in self.process.stdout: self.responses.put(line)
            self.responses.put(None)
        threading.Thread(target=receive, daemon=True).start()
        self.rig = int(rig)
    def request(self, action, **args):
        self.process.stdin.write(json.dumps(dict(action=action, rig=self.rig, **args))+'\n')
        self.process.stdin.flush()
        try: line = self.responses.get(timeout=3)
        except queue.Empty: raise CatError('OmniRig 响应超时；连接已停止，请检查驱动再重连')
        if line is None: raise CatError('OmniRig 进程已退出，请确认安装了 OmniRig 1.x')
        result = json.loads(line)
        if not result.get('ok'): raise CatError(result.get('error', 'OmniRig 错误'))
        return result
    def read(self):
        r = self.request('read')
        return {'frequency':frequency(r['frequency']), 'mode':r['mode']}
    def set_frequency(self, value): self.request('frequency', value=frequency(value))
    def set_mode(self, value): self.request('mode', value=value)
    def close(self):
        self.process.terminate()
        try: self.process.wait(timeout=1)
        except subprocess.TimeoutExpired: self.process.kill()

class Controller:
    """All CAT calls belong to one worker. Arming never survives reconnect."""
    def __init__(self, notify):
        self.notify = notify
        self.lock = threading.RLock()
        self.queue = queue.Queue(maxsize=32)
        self.generation = 0
        self.connection_generation = 0
        self.connected = self.armed = False
        self.step_index = 3
        self.invert = False
        self.pending = 0
        self.pending_time = 0
        self.freq = None
        self.mode = None
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def connect(self, factory):
        self.disconnect()
        self.queue.put(('connect', factory, self.generation, time.monotonic()))
    def disconnect(self):
        with self.lock:
            self.generation += 1
            self.connection_generation += 1
            self.connected = self.armed = False
            self.pending = 0
            while not self.queue.empty():
                try: self.queue.get_nowait()
                except queue.Empty: break
        self.notify('state', {'connected':False, 'armed':False})
    def arm(self, enabled):
        with self.lock:
            self.armed = bool(enabled and self.connected)
            self.pending = 0
            # Discard queued input on both edges of arming.
            self.generation += 1
        self.notify('state', {'armed':self.armed})
    def submit(self, action, value=0):
        with self.lock:
            if not self.armed: return False
            if action=='tune':
                self.pending = max(-20, min(20, self.pending + int(value)*(-1 if self.invert else 1)))
                self.pending_time = time.monotonic()
                return True
            try: self.queue.put_nowait((action, value, self.generation, time.monotonic()))
            except queue.Full: return False
            return True
    def _publish(self, state):
        self.freq, self.mode = state['frequency'], state['mode']
        self.notify('radio', {**state, 'step':STEPS[self.step_index]})
    def _active(self, generation):
        with self.lock: return self.armed and generation == self.generation
    def _confirm(self, backend, gen, freq=None, mode=None):
        deadline = time.monotonic()+2
        while True:
            if not self._active(gen): return
            state = backend.read()
            if not self._active(gen): return
            if (freq is None or state['frequency']==freq) and (mode is None or state['mode']==mode):
                self._publish(state); return
            if time.monotonic()>=deadline: raise CatError('电台未回读确认设置，控制已停止；请检查 CAT 驱动、范围或模式支持')
            time.sleep(.1)
    def _run(self):
        backend = None
        last_poll = 0
        while not self.stop.is_set():
            session = self.connection_generation
            try:
                try: action, value, gen, created = self.queue.get(timeout=.08)
                except queue.Empty: action, value, gen, created = 'poll', 0, self.generation, time.monotonic()
                session = self.connection_generation
                with self.lock:
                    if not self.connected and backend:
                        backend.close(); backend = None
                    if gen != self.generation: continue
                if action=='connect':
                    candidate = value()
                    try: state = candidate.read()
                    except Exception:
                        candidate.close(); raise
                    with self.lock:
                        if gen != self.generation: candidate.close(); continue
                        backend = candidate; self.connected = True
                    self._publish(state)
                    self.notify('state', {'connected':True, 'armed':False})
                    last_poll = time.monotonic()
                    continue
                if not backend: continue
                with self.lock:
                    if action != 'poll' and (not self.armed or time.monotonic()-created>.8): continue
                    if action=='poll' and self.armed and self.pending:
                        value, self.pending = self.pending, 0
                        if time.monotonic()-self.pending_time<=.8: action='tune'
                if action in ('step_down', 'step_up'):
                    self.step_index = max(0, min(len(STEPS)-1, self.step_index+(-1 if action=='step_down' else 1)))
                    self.notify('step', STEPS[self.step_index])
                elif action=='tune':
                    state = backend.read()
                    if not self._active(gen): continue
                    target = frequency(state['frequency']+int(value)*STEPS[self.step_index])
                    backend.set_frequency(target); self._confirm(backend, gen, freq=target)
                elif action in ('mode_prev', 'mode_next'):
                    state = backend.read(); current = state['mode']
                    if not self._active(gen): continue
                    index = MODES.index(current) if current in MODES else -1
                    target = MODES[(index+(-1 if action=='mode_prev' else 1))%len(MODES)]
                    backend.set_mode(target); self._confirm(backend, gen, mode=target)
                elif action in ('band_prev', 'band_next'):
                    state = backend.read()
                    if not self._active(gen): continue
                    index = min(range(len(BANDS)), key=lambda i:abs(BANDS[i][1]-state['frequency']))
                    target = BANDS[(index+(-1 if action=='band_prev' else 1))%len(BANDS)][1]
                    backend.set_frequency(target); self._confirm(backend, gen, freq=target)
                elif time.monotonic()-last_poll>=.6:
                    self._publish(backend.read()); last_poll = time.monotonic()
            except Exception as e:
                if backend:
                    try: backend.close()
                    except Exception: pass
                    backend = None
                if session == self.connection_generation:
                    self.disconnect()
                    self.notify('error', str(e))
        if backend: backend.close()
    def close(self):
        self.disconnect(); self.stop.set()
