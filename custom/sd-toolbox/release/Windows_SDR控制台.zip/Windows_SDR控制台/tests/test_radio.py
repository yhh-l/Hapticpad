import queue
import socketserver
import sys
import threading
import time
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from radio import Controller, Demo, Hamlib, CatError, frequency, MODE_BITS

class FakeRig(socketserver.StreamRequestHandler):
    def handle(self):
        for raw in self.rfile:
            cmd=raw.decode().strip(); self.server.commands.append(cmd)
            if cmd=='+f': reply=f'get_freq:\nFrequency: {self.server.freq}\nRPRT 0\n'
            elif cmd=='+m': reply=f'get_mode:\nMode: {self.server.mode}\nPassband: 2400\nRPRT 0\n'
            elif cmd.startswith('+F '):
                self.server.freq=int(cmd[3:]);reply='set_freq:\nRPRT 0\n'
            elif cmd.startswith('+M '):
                mode=cmd.split()[1]
                if mode=='FM': reply='set_mode:\nRPRT -4\n'
                else:self.server.mode=mode;reply='set_mode:\nRPRT 0\n'
            else: reply='RPRT -1\n'
            self.wfile.write(reply.encode());self.wfile.flush()

class Tests(unittest.TestCase):
    def test_real_tcp_erp_read_write_and_error(self):
        server=socketserver.ThreadingTCPServer(('127.0.0.1',0),FakeRig)
        server.freq,server.mode,server.commands=7100000,'LSB',[]
        threading.Thread(target=server.serve_forever,daemon=True).start()
        rig=Hamlib('127.0.0.1',server.server_address[1])
        try:
            self.assertEqual(rig.read(),dict(frequency=7100000,mode='LSB'))
            rig.set_frequency(7100100);rig.set_mode('USB')
            self.assertEqual(rig.read(),dict(frequency=7100100,mode='USB'))
            with self.assertRaises(CatError):rig.set_mode('FM')
            self.assertIn('+M USB 0',server.commands)
        finally:rig.close();server.shutdown();server.server_close()
    def wait(self, condition):
        deadline=time.monotonic()+3
        while not condition():
            if time.monotonic()>deadline:self.fail('worker timed out')
            time.sleep(.01)
    def test_controller_arm_coalesce_step_modes_band_disconnect(self):
        events=queue.Queue();rig=Demo();c=Controller(lambda *v:events.put(v))
        try:
            c.connect(lambda:rig);self.wait(lambda:c.connected)
            self.assertFalse(c.submit('tune',3));self.assertEqual(rig.freq,7100000)
            c.arm(True)
            c.submit('tune',2);c.submit('tune',3)
            self.wait(lambda:rig.freq==7100500)
            c.submit('step_up');self.wait(lambda:c.step_index==4)
            c.invert=True;c.submit('tune',1);self.wait(lambda:rig.freq==7100000)
            c.submit('mode_next');self.wait(lambda:rig.mode=='USB')
            c.submit('band_next');self.wait(lambda:rig.freq==10120000)
            c.arm(False);self.assertFalse(c.submit('tune',1))
            c.disconnect();c.connect(lambda:rig);self.wait(lambda:c.connected)
            self.assertFalse(c.armed);self.assertEqual(rig.freq,10120000)
        finally:c.close();c.thread.join(3)
    def test_cat_failure_disconnects_and_drops_pending(self):
        class Broken(Demo):
            def set_frequency(self,value):raise CatError('broken')
        events=queue.Queue();c=Controller(lambda *v:events.put(v))
        try:
            c.connect(Broken);self.wait(lambda:c.connected);c.arm(True);c.submit('tune',1)
            self.wait(lambda:not c.connected)
            self.assertFalse(c.armed);self.assertEqual(c.pending,0)
            self.assertTrue(any(k=='error' for k,v in list(events.queue)))
        finally:c.close();c.thread.join(3)
    def test_disarm_discards_inflight_queued_input(self):
        c=Controller(lambda *v:None);rig=Demo()
        try:
            c.connect(lambda:rig);self.wait(lambda:c.connected);c.arm(True)
            with c.lock:
                c.submit('mode_next');c.submit('tune',10);c.arm(False)
            time.sleep(.2)
            self.assertEqual(rig.read(),dict(frequency=7100000,mode='LSB'))
        finally:c.close();c.thread.join(3)
    def test_numeric_validation(self):
        for bad in ('nan','inf',1,2000000001,7100000.5):
            with self.assertRaises(CatError):frequency(bad)
        self.assertEqual(frequency('7100000'),7100000)
    def test_stop_during_cat_read_does_not_send_another_write(self):
        entered, release = threading.Event(), threading.Event()
        class Slow(Demo):
            slow = False
            def read(self):
                if self.slow:
                    entered.set(); release.wait(2)
                return super().read()
        rig=Slow();c=Controller(lambda *v:None)
        try:
            c.connect(lambda:rig);self.wait(lambda:c.connected);c.arm(True)
            rig.slow=True;c.submit('tune',1)
            self.assertTrue(entered.wait(2));c.arm(False);release.set()
            time.sleep(.2);self.assertEqual(rig.freq,7100000)
        finally:release.set();c.close();c.thread.join(3)
    def test_initial_connection_error_is_reported(self):
        events=queue.Queue();c=Controller(lambda *v:events.put(v))
        def fail():raise CatError('not installed')
        try:
            c.connect(fail)
            self.wait(lambda:any(k=='error' for k,v in list(events.queue)))
            self.assertFalse(c.connected)
        finally:c.close();c.thread.join(3)
    def test_reconnect_is_not_cleared_by_old_connection_failure(self):
        entered, release = threading.Event(), threading.Event()
        class SlowFail(Demo):
            def read(self):
                entered.set();release.wait(2);raise CatError('old failure')
        c=Controller(lambda *v:None);rig=Demo()
        try:
            c.connect(SlowFail);self.assertTrue(entered.wait(2))
            c.connect(lambda:rig);release.set();self.wait(lambda:c.connected)
            self.assertFalse(c.armed)
        finally:release.set();c.close();c.thread.join(3)
    def test_no_readback_confirmation_stops_controller(self):
        class ReadOnly(Demo):
            def set_frequency(self,value):pass
        c=Controller(lambda *v:None)
        try:
            c.connect(ReadOnly);self.wait(lambda:c.connected);c.arm(True);c.submit('tune',1)
            self.wait(lambda:not c.connected);self.assertFalse(c.armed)
        finally:c.close();c.thread.join(3)

if __name__=='__main__':unittest.main()
